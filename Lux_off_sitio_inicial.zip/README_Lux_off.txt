LUX_OFF — sitio inicial para GitHub Pages

ARCHIVOS
- index.html: página completa adaptable a celular y computadora.

CÓMO PUBLICAR EN GITHUB PAGES
1. Entra a github.com e inicia sesión.
2. Crea un repositorio nuevo llamado lux-off (o el nombre que prefieras).
3. Sube index.html a la raíz del repositorio.
4. Abre Settings > Pages.
5. En Build and deployment selecciona Deploy from a branch; elige la rama main y la carpeta /(root), y guarda.
6. Espera a que GitHub Pages publique el sitio y abre la URL que te muestre.

ANTES DE PUBLICAR
1. Abre index.html y busca WHATSAPP_NUMBER.
2. Sustituye 521XXXXXXXXXX por tu número completo de WhatsApp, solo números y con código de país. Para México normalmente es 52 + número; revisa el formato de WhatsApp que usas.
3. En initialProducts modifica los productos, precios, presentaciones y existencias. Los precios actuales son ejemplos de demostración.

IMPORTANTE SOBRE EL INVENTARIO
GitHub Pages publica sitios estáticos. Este prototipo permite mostrar el catálogo, filtrar perfumes, armar el carrito y enviar el pedido o una solicitud especial por WhatsApp. Sin embargo, no sincroniza reservas entre diferentes clientes ni proporciona un panel privado seguro para que el dueño confirme o libere existencias. Para que una reserva quite stock para todos los visitantes y puedas confirmarla o devolverla al inventario desde un panel, hay que conectar una base de datos/backend (por ejemplo Supabase o Firebase) y definir acceso de administrador. No pongas contraseñas ni claves secretas en index.html.
