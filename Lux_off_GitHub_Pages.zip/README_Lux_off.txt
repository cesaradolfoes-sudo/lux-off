# Lux_off — tienda de perfumes

Sitio estático para GitHub Pages con catálogo de **botellas completas**, carrito, solicitud de perfumes por WhatsApp y panel de administración. El diseño usa negro, tonos carbón y detalles dorados.

## Archivos

- `index.html`: página web.
- `supabase-schema.sql`: tablas, políticas de seguridad y funciones para reservar, confirmar ventas y cancelar reservas.
- `README_Lux_off.txt`: estas instrucciones en español.

## Importante antes de publicar

GitHub Pages solo sirve archivos estáticos. El inventario compartido y el panel requieren Supabase (plan gratuito suele bastar para empezar). Sin Supabase configurado, la página muestra productos de demostración y no crea reservas reales.

## 1. Crear el backend en Supabase

1. Entra a https://supabase.com/ y crea un proyecto.
2. En el proyecto, abre **SQL Editor → New query**.
3. Abre `supabase-schema.sql`, copia todo y ejecútalo.
4. En **Authentication → Users**, crea tu usuario con tu correo y una contraseña segura.
5. Copia el UUID de ese usuario.
6. En SQL Editor ejecuta, sustituyendo el UUID por el tuyo:

   ```sql
   insert into public.admin_users(user_id)
   values ('PEGA-AQUI-EL-UUID-DE-TU-USUARIO');
   ```

   Esta lista controla quién puede usar las funciones administrativas. No compartas la contraseña.

7. En **Project Settings → API** (o **Connect**), copia el **Project URL** y la clave **anon/public**. No uses `service_role`.

## 2. Conectar la web a Supabase

Abre `index.html` y busca al principio del script:

```js
const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU_SUPABASE_ANON_KEY";
const WHATSAPP_NUMBER = "529512038764";
```

Reemplaza `SUPABASE_URL` y `SUPABASE_ANON_KEY` por los valores de tu proyecto. El WhatsApp ya está configurado para el número proporcionado en formato internacional de México (52 + 10 dígitos). Confirma que ese número tiene WhatsApp antes de publicar.

La clave `anon/public` está diseñada para usarse en el navegador con Row Level Security habilitado. **Nunca** coloques la clave `service_role` en `index.html`, GitHub ni en el navegador.

## 3. Publicar en GitHub Pages

1. Inicia sesión en https://github.com/ y crea un repositorio, por ejemplo `lux-off`.
2. Descarga y descomprime este ZIP en tu computadora.
3. En el repositorio pulsa **Add file → Upload files**.
4. Sube `index.html` y `supabase-schema.sql` (y opcionalmente este README). Confirma con **Commit changes**.
5. Abre **Settings → Pages**.
6. En **Build and deployment**, selecciona **Deploy from a branch**.
7. Elige la rama `main` y la carpeta `/ (root)`, pulsa **Save**.
8. Espera a que termine el despliegue. GitHub mostrará la URL pública de tu sitio en esa misma sección.

## 4. Cómo se administra

- Inicia sesión en la sección **Panel de administración** de la página con el usuario creado en Supabase.
- Agrega perfumes completos, marca, nombre, precio en MXN y existencias.
- En inventario puedes modificar precio, existencias u ocultar/reactivar productos.
- Al completar el formulario del carrito, el backend crea una reserva y aumenta `reserved`; el catálogo muestra `stock - reserved` como disponible.
- Se abre WhatsApp con el número de pedido y el resumen.
- En el panel, **Confirmar venta** descuenta la cantidad de `stock` y libera la reserva.
- **Cancelar / liberar stock** libera la reserva sin descontar las existencias.

Las reservas no expiran automáticamente en esta versión: revísalas en el panel y cancela manualmente las que no se concreten. No prometas disponibilidad hasta confirmar el pedido.

## 5. Antes de vender de verdad

- Cambia los precios y existencias de ejemplo por tu inventario real.
- Prueba una reserva y luego cancélala; prueba otra y confírmala.
- Revisa que tu usuario sea el único registrado en `admin_users`.
- No recolectes datos innecesarios. Los pedidos guardan nombre y teléfono para atender la solicitud.
- El sitio no procesa pagos; tú confirmas el pago y la entrega por mensaje.
- Considera establecer una política de privacidad, cambios/devoluciones y envíos.

## Limitaciones conocidas de esta versión

- El catálogo usa una ilustración genérica de frasco, no fotos oficiales de cada perfume.
- Los pedidos se gestionan manualmente por WhatsApp; no hay cobro en línea.
- Las reservas se liberan manualmente desde el panel.
- El proyecto de Supabase debe estar configurado antes de que el inventario y panel funcionen de manera compartida.
